package com.bank.view;

public interface MoneyDispenserMachine {
	public void changePin();
	public void withdrawMoney(ATM machine,int amount);
}
