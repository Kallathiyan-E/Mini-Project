package com.bank.view;

import com.bank.entity.AccountHolders;

public class SwipeMachine {
	public void swipeCard(AccountHolders machine,int amount) {
		int balance = machine.getBalance();
		int cashBack = (int) machine.getCard().cashBack(amount);
		if(amount+cashBack>balance)
			System.out.println("Insufficient Balance.Transaction Failed!");
		else if(machine.checkMinimumBalance((balance+cashBack)-amount)) {
			System.out.println("Cashback USD :"+cashBack);
			System.out.println("Balance USD :"+(balance+cashBack-amount));
			machine.setBalance(balance+cashBack+amount);
		}
		else {
			System.out.println("CashBack USD :"+cashBack);
			System.out.println("Balance USD :"+(balance+cashBack-amount));
			machine.setBalance(balance+cashBack-amount);
		}
	}
}
