package com.bank.view;

import com.bank.entity.AccountHolders;

public interface MoneyDispenserMachine {
	public void changePin();
	public void withdrawMoney(AccountHolders machine,int amount);
}
