package com.bank.view;

import com.bank.entity.AccountHolders;

public interface MoneyDepositMachine {
	public boolean checkMinimumBalance(int amount);
	public int depositMoney(AccountHolders machine,int amount);
}